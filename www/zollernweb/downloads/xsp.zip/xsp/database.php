<?php
require 'xsp.php';

$xsp = new XSP();

$xsp->Parse('');
?>