<?php
	echo '<pre>';
	show_source("xsp.php");
	echo '</pre>';
?>